#include<iostream>
#include<fstream>
#include<cstring>
#include<istream>
#include<string>
#include <time.h>

using namespace std;




struct item{
	string name;
	int cost;
};
int bestdifference = 100000000;
int* best;
int besta = 0;
int bestb = 0;

int difference;
void checkResult(int*binary, int items, item*itemlist) {
	int acost = 0;
	int bcost = 0;
	for (int i = 0; i < items; i++){
		if (binary[i] == 0){
			acost += itemlist[i].cost;
		}
		else bcost += itemlist[i].cost;
	}
	difference = abs(acost - bcost);
	if (bestdifference > difference){
		besta = acost;
		bestb = bcost;
		bestdifference = difference;
		for (int i = 0;i<items;i++){
			best[i] = binary[i];
		}
	}
	

}

void generate(int i,int*binary,int items,item*itemlist) {
	for (int k = 0; k <= 1; k++) {
		binary[i] = k;
		if (i == items - 1)
			checkResult(binary,items,itemlist);
		else
			generate(i + 1,binary,items,itemlist);
	}
}
int main(){
	clock_t t;
	t = clock();
	ifstream fin;
	fin.open("item.txt");
	int items;
	string temp;
	int pos = 0;
	getline(fin, temp);
	items = stoi(temp);
	item*itemlist = new item[items];
	best = new int[items];
	while (!fin.eof()){
		getline(fin, itemlist[pos].name,' ');
		getline(fin, temp);
		itemlist[pos].cost = stoi(temp);
		pos++;
		
	}
	cout << "Number of items:" << items << endl;
	for (int i = 0; i < items; i++){
		cout << itemlist[i].name << ' ' << itemlist[i].cost << endl;
	}
	int*binary = new int[items];
	generate(0, binary, items,itemlist);
	ofstream fout;
	fout.open("divide.txt");
	fout << besta << ' ' << bestb << ' ' << bestdifference << endl;
	for (int i = 0; i < items; i++){
		if (best[i] == 0){
			fout << itemlist[i].name << ' ';
		}
	}
	fout << endl;
	for (int i = 0; i < items; i++){
		if (best[i] != 0){
			fout << itemlist[i].name << ' ';
		}
	}
	

	delete[] binary;
	delete[] itemlist;
	delete[] best;
	t = clock() - t;
	float seconds = t / CLOCKS_PER_SEC;
	float minutes = seconds / 60;
	cout << "It took " << minutes << " minutes";
	return 0;
}