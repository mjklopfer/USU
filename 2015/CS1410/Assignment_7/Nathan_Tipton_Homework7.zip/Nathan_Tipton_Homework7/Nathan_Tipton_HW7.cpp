#include<iostream>
#include<fstream>
#include<cstring>
#include<istream>
#include<string>


using namespace std;

const int N = 10;
int path[N], best[N], cost[N][N];
int bestcost = 1000000000;
bool used[N];
int pos = 0;
struct city_struct{

	string name;
	int cnum;
};

int search(string key, city_struct*cityarray){
	for (int i = 0; i < N; i++){
		
		if (cityarray[i].name == key)
			return i;
	}
	return -1;
}

void output(){}
void setup() {
	
	cost[0][1] = cost[1][0] = 50;
	cost[0][3] = cost[3][0] = 80;
	cost[1][2] = cost[2][1] = 100;
	cost[1][3] = cost[3][1] = 40;
	cost[2][3] = cost[3][2] = 40;
	cost[2][0] = cost[0][2] = 150;
	
}

void checkResult() {
	int totalcost = 0;

	/*cout << "\n Checking this path: ";
	for (int i = 0; i < N; i++)   // printing...
		cout << path[i] << ' ';*/


	if (cost[path[N - 1]][path[0]] == 0)  // no path from last city back to first city
		return;

	for (int i = 0; i < N - 1; i++) {
		if (cost[path[i]][path[i + 1]] == 0)  // no path from last city back to first city
			return;
		totalcost += cost[path[i]][path[i + 1]];
	}

	//totalcost += cost[path[N - 1]][path[0]]; // come back to the first city
	if (path[0]==0 && path[N - 1]==N-1){
		if (bestcost > totalcost){
			bestcost = totalcost;
			for (int i = 0; i < N; i++)
				best[i] = path[i];

			cout << "\n Found a better solution with total cost of " << totalcost << endl;
		}
	}
		//for (int i = 0; i < N; i++)   // printing...
		//	cout << path[i] << ' ';

	
}

void permute(int i) {
	for (int k = 0; k < N; k++) {
		if (!used[k]) {
			path[i] = k;
			used[k] = true;

			if (i == N - 1)
				checkResult();
			else
				permute(i + 1);

			used[k] = false;
		}
	}
}

int main() {
	int num1, num2;
	int cities;
	int test;
	ifstream fin;
	string S, T, city1, city2;
	int ccost;
	fin.open("tsp.in");
	fin >> cities;
	city_struct*cityarray = new city_struct[cities];
	fin.ignore(1, ' ');
	getline(fin, S, ' ');
	getline(fin, T);
	cityarray[pos].name = S;
	cityarray[pos].cnum = 0;
	pos++;
	cityarray[cities - 1].name = T;
	cityarray[cities - 1].cnum = (cities - 1);
	while (!fin.eof()){
		getline(fin, city1, ' ');
		test = search(city1, cityarray);
		if (test == -1){
			cityarray[pos].name = city1;
			cityarray[pos].cnum = pos;
			num1 = pos;
			pos++;
		}
		else num1 = test;
		getline(fin, city2, ' ');
		test = search(city2,cityarray);
		if (test == -1){
			cityarray[pos].name = city2;
			cityarray[pos].cnum = pos;
			num2 = pos;
			pos++;
		}
		else num2 = test;
		fin >> ccost;
		cost[num1][num2] = cost[num2][num1] = ccost;
		fin.ignore(1, '\n');
	}
	cout << cities << " " << S << " " << T << endl;
	for (int i = 0; i < N; i++){
		cout << cityarray[i].name <<" "<<cityarray[i].cnum<< endl;
	}
	
	
	permute(0);
	ofstream fout;
	fout.open("tsp.out");
	fout << bestcost << endl;
	
	for (int i = 0; i < N; i++){
		for (int j = 0; j < N;j++)
		if (cityarray[j].cnum == best[i]){
			fout << cityarray[j].name << endl;
		}
		
	}

	delete[] cityarray;
	return 0;
}