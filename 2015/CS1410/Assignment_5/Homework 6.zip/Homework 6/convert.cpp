#include <iostream>
#include <fstream>
#include <string>
using namespace std;

struct BNKHeader {
	char signature[4];  //{'B', 'A', 'N', 'K'};
	int numberofaccounts;
	char reserved[24];
};
struct BNKAccount {
	int number;
	char name[20];
	double balance;
	char reserved[96];
};
struct BNKIndex {
	int accountNumber;
	long filePosition;
};
BNKHeader bank;
BNKIndex index;
BNKAccount acct;
int readCSVlines(string file){
	string line;
	int numAccounts=0;

	ifstream input;
	input.open(file);
	if (input.is_open()){
		cout << "File Open" << endl;
		getline(input, line);
		while (!input.eof()){
			getline(input, line);
			cout << line << endl;
			numAccounts++;
		}
		
	}
	else cout << "Did not Open" << endl;
	input.close();
	return numAccounts;
}
void writeBinaryBNK(string file){
	 
	int acctNum;
	string holder;
	double balance;
	string info;
	ofstream BNKfile("Accounts.bnk",ios::binary);
	bank.signature[0] = 'B';
	bank.signature[1] = 'A';
	bank.signature[2] = 'N';
	bank.signature[3] = 'K';

	BNKfile.write((char*)(&bank), sizeof(BNKHeader));
	BNKIndex* Accounts;
	Accounts = new BNKIndex[bank.numberofaccounts];
	ifstream input;
	input.open(file);
	int pos = 32;
	getline(input, info);
	cout << "Size of BNKAccount: " << sizeof(BNKAccount) << endl;
	cout << "Size of BNKHeader: " << sizeof(BNKHeader) << endl;
	cout << "Size of BNKIndex: " << sizeof(BNKIndex) << endl;

	for (int i = 0; i < bank.numberofaccounts; i++){

		getline(input, info, ',');
		acctNum = stoi(info);
		acct.number = acctNum;
		getline(input, holder, ',');
		getline(input, info);
		balance = stod(info);
		strncpy_s(acct.name, holder.c_str(), sizeof(acct.name));
		acct.balance = balance;
		Accounts[i].accountNumber = acct.number;
		Accounts[i].filePosition = BNKfile.tellp();
		BNKfile.write((char*)&acct, sizeof(BNKAccount));
		
	}
	BNKIndex temp;
	for (int i = 0; i < bank.numberofaccounts; i++){
		for (int j = i + 1; j < bank.numberofaccounts; j++){
			if (Accounts[i].accountNumber>Accounts[j].accountNumber){
				temp = Accounts[i];
				Accounts[i] = Accounts[j];
				Accounts[j] = temp;
			}
		}
	}
	for (int i = 0; i < bank.numberofaccounts;i++){
		
		BNKfile.write((char*)&Accounts[i], sizeof(BNKIndex));
		cout << "Account Number: " << Accounts[i].accountNumber << " is stored at position " << Accounts[i].filePosition << endl;
	}
	
	

	for (int i = 0; i < bank.numberofaccounts; i++){
		BNKfile << Accounts[i].accountNumber << Accounts[i].filePosition;
	}
	BNKfile.close();
	delete[] Accounts;
	
}

int main(){
	string file;
	int numAccts=0;
	cout << "Enter name of file to be converted: ";
	getline(cin, file);
	bank.numberofaccounts = readCSVlines(file);
	writeBinaryBNK(file);
	

	cout << " The number of accounts in the CSV file is " << bank.numberofaccounts << endl;






	return 0;
}