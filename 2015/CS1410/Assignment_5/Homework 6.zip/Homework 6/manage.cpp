#include <iostream>
#include <fstream>
#include <string>
using namespace std;
struct BNKHeader {
	char signature[4]; // {'B','A','N','K'};
	int numberOfAccounts;
	char reserved[24];
};
struct BNKAccount {
	int number;
	char name[20];
	double balance;
	char reserved[96];
};
struct BNKIndex {
	int accountNumber;
	long filePosition;
};
BNKHeader header;
BNKAccount acct;
BNKIndex ind;

bool readHeader(fstream &fin){
	string file;
	
	cout << "Enter name of BNK file to manage: ";
	cin >> file;
	fin.open(file, ios::binary|ios::in|ios::out);
	if (fin.fail()){
		cout << "Error: cannot open BNK file!" << endl;
		return false;
	}
	
	fin.read((char*)&header, sizeof(header));
	if (header.signature[0] == 'B' && header.signature[1] == 'A' && header.signature[2] == 'N'&& header.signature[3]=='K') {
		cout << "This is a valid BNK file." << endl;
		return true;
	}
	else return false;
	
}
void readIndex(fstream &fin, BNKIndex* ind){
	int num;
	num = header.numberOfAccounts;
	fin.seekg(sizeof(BNKHeader) + num * sizeof(BNKAccount), ios::beg);
	for (int i = 0; i < num; i++){
		fin.read((char*)&ind[i], sizeof(ind[i]));
	}
/*	BNKIndex temp;
	for (int i = 0; i < header.numberOfAccounts; i++){
		for (int j = i + 1; j < header.numberOfAccounts; j++){
			if (ind[i].accountNumber>ind[j].accountNumber){
				temp = ind[i];
				ind[i] = ind[j];
				ind[j] = temp;
			}
		}
	}*/
}
int getfileposition(int acct, BNKIndex* ind){
	int first = 0;
	int last = header.numberOfAccounts - 1;

	do {
		int mid = (first + last) / 2;

		if (ind[mid].accountNumber == acct)
			return ind[mid].filePosition;

		if (ind[mid].accountNumber < acct)
			first = mid + 1;
		else
			last = mid - 1;
	} while (first <= last);
	return -1;

}
void deposit(fstream &fin, BNKIndex* ind){
	int acct;
	int test;
	double deposit;
	double balance;
	
	cout << "Enter account number: ";
		cin >> acct;

		test = getfileposition(acct,ind);
		while (test == -1){
		cout << "Invalid Account Number, Please try again." << endl;
		cin >> acct;
		test = getfileposition(acct,ind);
		};
		
		
		cout << endl << "Enter deposit amount: ";
		cin >> deposit;
		test += sizeof(int)+sizeof(char[20]);
		cout << "TEST::::" << test << endl;
		fin.seekg(test, ios::beg);
		fin.read((char*)&balance, sizeof(double));
		cout << "Balance:::" << balance;
			balance += deposit;
			cout << "Balance2:::" << balance;
			fin.seekg(test, ios::beg);
			cout << "TESTWRITE::" << test;
			fin.write((char*)&balance, sizeof(double));


}
void withdraw(fstream &fin, BNKIndex* ind){
	int acct;
	int test;
	double withdraw;
	double balance;

	cout << "Enter account number: ";
	cin >> acct;

	test = getfileposition(acct, ind);
	while (test == -1){
		cout << "Invalid Account Number, Please try again." << endl;
		cin >> acct;
		test = getfileposition(acct, ind);
	};


	cout << endl << "Enter withdraw amount: ";
	cin >> withdraw;
	test += sizeof(int) + sizeof(char[20]);
	//cout << "TEST::::" << test << endl;
	fin.seekg(test, ios::beg);
	fin.read((char*)&balance, sizeof(double));
	//cout << "Balance:::" << balance;
	balance -= withdraw;
	//cout << "Balance2:::" << balance;
	fin.seekg(test, ios::beg);
	//cout << "TESTWRITE::" << test;
	fin.write((char*)&balance, sizeof(double));

}
void display(fstream &fin, BNKIndex* ind){
	int acct;
	int test;
	string name;
	double balance;
	cout << "Enter account number: ";
	cin >> acct;
	BNKAccount a;
	test = getfileposition(acct, ind);
	//cout << "Test:::" << test;
	while (test == -1){
		cout << "Invalid Account Number, Please try again." << endl;
		cin >> acct;
		test = getfileposition(acct, ind);
	};
	fin.seekg(test, ios::beg);
	fin.read((char*)&a, sizeof(BNKAccount));
	cout << "Account Number: " << a.number << endl;
	cout << "Account Holder: " << a.name << endl;
	cout << "Account Balance: $" << a.balance << endl;

}
void displayall(fstream &fin, BNKIndex* ind,int num){
	BNKAccount a;
	fin.seekg(sizeof(BNKHeader), ios::beg);
	for (int i = 0; i < num; i++){
		fin.read((char*)&a, sizeof(BNKAccount));
		cout << "Account Number: " << a.number << endl;
		cout << "Account Holder: " << a.name << endl;
		cout << "Account Balance: $" << a.balance << endl;
	}

}

int main(){
	bool input;
	fstream fin;
	input = readHeader(fin);
	
	
	if (!input){
		cout << "Please use a valid BNK file!" << endl;
		return 0;
	}
	BNKIndex* index;
	index = new BNKIndex[header.numberOfAccounts];
	readIndex(fin, index);
	for (int i = 0; i < header.numberOfAccounts; i++){
		cout << index[i].accountNumber << " " << index[i].filePosition << endl;
	}
	int choice;
	do{
		cout << endl;
		cout << "-- What would you like to do? --" << endl;
		
		cout << "1 - Deposit to an existing account \n";
		cout << "2 - Withdraw from an existing account \n";
		cout << "3 - Display Account\n";
		cout << "4 - Display All Accounts\n";
	
		cout << "5 - Quit\n";
		cout << "Please type a number 1 - 5: ";

		cin >> choice;
		cout << endl;
		switch (choice){
		case 1:

			deposit(fin,index);
			break;
		case 2:
			withdraw(fin, index);
			break;
		case 3:
			display(fin, index);
			break;
		case 4:
			displayall(fin, index,header.numberOfAccounts);
			break;
		case 5: cout << "Goodbye!\n";
			break;
		default: cout << "That is not a valid choice. Please try again.\n";
		
		}
	} while (choice != 5);
	fin.close();
	delete index;
	

	return 0;
}