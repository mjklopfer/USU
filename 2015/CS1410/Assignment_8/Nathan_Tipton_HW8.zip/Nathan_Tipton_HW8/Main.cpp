#include <iostream>
#include <vector>
#include <string>
using namespace std;
#include "Course.h"
#include "Person.h"
#include "Professor.h"
#include "Student.h"

//Search vector for a person
Person* findPerson(int ID, vector<Person*> people) {
	for (int i = 0; i < people.size(); i++)
		if (ID == people[i]->ID)
			return people[i];
	return NULL;
}


int main(){
	vector<Person*> people;
	Person* temp;
	Person* find;
	
	int choice;
	int studentid;
	int profid;
	string schoice;
	do{

		cout << "-- Select Your Choice --" << endl;
		cout << "1. Add a Professor" << endl;
		cout << "2. Add a Student" << endl;
		cout << "3. Add a course for a student" << endl;
		cout << "4. Print the transcript of a student" << endl;
		cout << "5. Print information of a professor" << endl;
		cout << "6. Quit" << endl;
		getline(cin, schoice);
		choice = stoi(schoice);
		switch (choice){
		case 1:
			//Create new professor
			temp = new Professor();
			temp->read();
			people.push_back(temp);
	
			break;
		case 2:
			//create new student
			temp = new Student();
			temp->read();
			people.push_back(temp);
			
			break;
		case 3:
			//create course for student
			
			cout << "Enter Student ID: ";
			getline(cin, schoice);
			studentid = stoi(schoice);
			find = findPerson(studentid, people);
			if (find != NULL){
				Student* student = dynamic_cast<Student*> (find);
				if (student != NULL) {  // the person with this ID is a Student
					course *ncourse = new course();
					ncourse->read();
					student->courses.push_back(ncourse);
				}
				else {
					cout << "The person with this ID is NOT a Student! " << endl;
				}
			}
			
			
			break;
		case 4:
			//Print transcript for student
			
			cout << "Enter Student ID: ";
			getline(cin, schoice);
			studentid = stoi(schoice);
			find = findPerson(studentid, people);
			if (find != NULL){
				Student* student = dynamic_cast<Student*> (find);
				if (student != NULL) {  // the person with this ID is a Student
					student->write();
					cout << endl;
					for (int i = 0; i < student->courses.size(); i++){
						student->courses.at(i)->write();
						cout << endl;
					}
					cout << "Cumulative Hours: " << student->totalhours() << " Cumulative GPA: " << student->totalgpa() << endl;
				}
				else {
					cout << "The person with this ID is NOT a Student! " << endl;
				}
			}
			break;
		case 5:
			//Print professor information
			
			cout << "Enter professor ID: ";
			getline(cin, schoice);
			profid = stoi(schoice);
			find = findPerson(profid, people);
			if (find != NULL){
				Professor* prof = dynamic_cast<Professor*> (find);
				if (prof != NULL) {  // the person with this ID is a Professor
					prof->write();
				}
				else {
					cout << "The person with this ID is NOT a Professor! " << endl;
				}
			}
			break;
		default: cout << "That is not a valid choice. Please try again.\n";
		case 6: cout << "Goodbye!\n";
		}
	} while (choice != 6);
	return 0;
}