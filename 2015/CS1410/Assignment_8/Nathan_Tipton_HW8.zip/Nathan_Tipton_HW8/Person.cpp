#include <iostream>
#include <vector>
#include <string>

using namespace std;
#include "Person.h"

void Person::read(){
	string ptemp;
	cout << "ID: ";	getline(cin, ptemp);
	ID = stoi(ptemp);
	cout << "Name: "; getline(cin, name);
	cout << "Date of birth: "; getline(cin, dob);
	cout << "Gender: "; getline(cin, gender);
	cout << "Address: "; getline(cin, address);
}
void Person::write(){
	cout << "ID: " << ID << endl;
	cout << "Name: " << name << endl;
	cout << "Date of birth: " << dob << endl;
	cout << "Gender: " << gender << endl;;
	cout << "Address: " << address << endl;
}


int Person::getID(){
	return ID;
}
void Person::setID(int x){
	ID = x;
	return ;
}
string Person::getaddress(){
	return address;
}
void Person::setaddress(string x){
	address = x;
	return;
}
string Person::getdob(){
	return dob;
}
void Person::setdob(string x){
	dob = x;
	return;
}
string Person::getgender(){
	return gender;
}
void Person::setgender(string x){
	gender = x;
	return;
}
string Person::getname(){
	return name;
}
void Person::setname(string x){
	name = x;
	return;
}

