#ifndef STUDENT_H
#define STUDENT_H
#include "Person.h"
#include "Course.h"
class Student :public Person{
public:
	string major, temp;

	vector<course*> courses;
	string getmajor();
	int totalhours();
	virtual double totalgpa();
	void setmajor(string);
	virtual void read();
	virtual void write();
	Student(){
		major = "";
		
	}
};





#endif