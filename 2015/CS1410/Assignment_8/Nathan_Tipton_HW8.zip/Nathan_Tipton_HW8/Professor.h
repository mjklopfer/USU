#ifndef PROFESSOR_H
#define PROFESSOR_H
#include "Person.h"
class Professor :public Person{
public:
	string title, office;
	double salary;

	double getsalary();
	string gettitle(), getoffice();
	void setsalary(double), settitle(string), setoffice(string);
	virtual void read();
	virtual void write();
	Professor(){
		salary = 0;
		title, office = "";
	}

};




#endif
