#include <iostream>
#include <vector>
#include <string>

using namespace std;
#include "Student.h"

double Student::totalgpa(){
	double gpa = 0;
	double total = 0;
	double totalclasses = 0;
	for (int i = 0; i < courses.size(); i++){
		totalclasses += courses.at(i)->credits;
	}
	for (int i = 0; i < courses.size(); i++){
		string cgrade = courses.at(i)->grade;
		if (cgrade == "A+"){ total += courses.at(i)->credits*4; }
		if (cgrade == "A"){ total += courses.at(i)->credits * 4; }
		if (cgrade == "A-"){ total += courses.at(i)->credits*3.67; }
		if (cgrade == "B+"){ total += courses.at(i)->credits*3.33; }
		if (cgrade == "B"){ total += courses.at(i)->credits*3.0; }
		if (cgrade == "B-"){ total += courses.at(i)->credits*2.67; }
		if (cgrade == "C+"){ total += courses.at(i)->credits*2.33; }
		if (cgrade == "C"){ total += courses.at(i)->credits*2.0; }
		if (cgrade == "C-"){ total += courses.at(i)->credits*1.67; }
		if (cgrade == "D+"){ total += courses.at(i)->credits*1.33; }
		if (cgrade == "D"){ total += courses.at(i)->credits*1.0; }
		if (cgrade == "D-"){ total += courses.at(i)->credits*.67; }
		if (cgrade == "F"){ total += courses.at(i)->credits * 0; }
		if (cgrade == "I"){ total += 0; totalclasses -= courses.at(i)->credits; }
		if (cgrade == "X"){ total += 0; totalclasses -= courses.at(i)->credits; }
	}
	gpa = (total / totalclasses);
	return gpa;
}
int Student::totalhours(){
	int total = 0;
	for (int i = 0; i < courses.size(); i++){
		total += courses.at(i)->credits;
	}
	return total;

}
void Student::read(){
	Person::read();
	cout << "Major: "; getline(cin, major);
}
void Student::write(){
	Person::write();
	cout << "Major: " << major << endl;
}
string Student::getmajor(){
	return major;
}
void Student::setmajor(string x){
	major = x;
	return;
}