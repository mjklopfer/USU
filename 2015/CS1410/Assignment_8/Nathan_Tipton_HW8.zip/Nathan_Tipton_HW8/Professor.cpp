#include <iostream>
#include <vector>
#include <string>

using namespace std;
#include "Professor.h"

void Professor::read(){
	string temp;
	Person::read();
	cout << "Job title: "; getline(cin, title);
	cout << "Office: "; getline(cin, office);
	cout << "Salary: "; getline(cin, temp); salary = stod(temp);
}
void Professor::write(){
	Person::write();
	cout << "Job title: " << title << endl;
	cout << "Office: " << office << endl;
	cout << "Salary: " << salary << endl;
}
string Professor::gettitle(){
	return title;
}
void Professor::settitle(string x){
	title = x;
	return;
}
string Professor::getoffice(){
	return office;
}
void Professor::setoffice(string x){
	office = x;
	return;
}
double Professor::getsalary(){
	return salary;
}
void Professor::setsalary(double x){
	salary = x;
	return;

}