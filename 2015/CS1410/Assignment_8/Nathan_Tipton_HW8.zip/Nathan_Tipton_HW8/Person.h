#ifndef PERSON_H
#define PERSON_H

class Person{
public:
	int ID;
	string name, dob, gender, address;

	int getID();
	
	void setID(int), setname(string), setdob(string), setgender(string), setaddress(string);
	string getname(), getdob(), getgender(), getaddress();
	virtual void read();
	virtual void write();
	Person(){
		ID = 0;
		name, dob, gender, address = "";
	}


};


#endif
