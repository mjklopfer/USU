#ifndef COURSE_H
#define COURSE_H
class course{
public:
	string course_ID;
	string name;
	string grade;
	string semester;
	int credits, year;

	string getID();
	string getname();
	string getgrade();
	string getsemester();
	int getcredits();
	int getyear();
	void setID(string), setname(string), setgrade(string), setsemester(string), setcredits(int), setyear(int);
	virtual void read();
	virtual void write();
};

#endif