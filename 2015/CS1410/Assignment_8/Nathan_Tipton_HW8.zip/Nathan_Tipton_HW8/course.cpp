#include <iostream>
#include <vector>
#include <string>

using namespace std;
#include "Course.h"

int course::getcredits(){
	return credits;
}
void course::setcredits(int x){
	credits = x;
	return;
}
string course::getgrade(){
	return grade;
}
void course::setgrade(string x){
	grade = x;
	return;
}
string course::getID(){
	return course_ID;
}
void course::setID(string x){
	course_ID = x;
	return;
}
string course::getsemester(){
	return semester;
}
void course::setsemester(string x){
	semester = x;
	return;
}
string course::getname(){
	return name;
}
void course::setname(string x){
	name = x;
	return;
}
int course::getyear(){
	return year;
}
void course::setyear(int x){
	year = x;
	return;
}
void course::read() {
	cout << "Course ID: "; 
	getline(cin, course_ID);
	cout << "Course Name: ";
	getline(cin, name);
	cout << "Course Credits: ";
	string temp;
	getline(cin, temp);
	credits = stoi(temp);
	cout << "Course Semester: ";
	getline(cin, semester);
	cout << "Course Year: ";
	getline(cin, temp);
	year = stoi(temp);
	cout << "Course Grade: ";
	getline(cin, grade);
}
void course::write(){
	cout << "Course ID: " << course_ID << endl;
	
	cout << "Course Name: " << name << endl;
	
	cout << "Course Credits: " << credits << endl;
	
	cout << "Course Semester: " << semester << endl;
	
	cout << "Course Year: " << year << endl;
	
	cout << "Course Grade: " << grade << endl;
	
}