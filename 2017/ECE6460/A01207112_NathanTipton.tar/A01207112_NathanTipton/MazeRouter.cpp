/*
 * MazeRouter.cpp
 * Work on this file to complete your maze router
 */

using namespace std;

#include "SimpleGR.h"

///////////////////////////////////////////////////////////////////////////////
// Implement an A* search based maze routing algorithm
// and a corresponding back-trace procedure
// The function needs to correctly deal with the following conditions:
// 1. Only search within a bounding box defined by botleft and topright points
// 2. Control if any overflow on the path is allowed or not
///////////////////////////////////////////////////////////////////////////////
CostType SimpleGR::routeMaze(Net& net, bool allowOverflow, const Point &botleft,
                             const Point &topright, const EdgeCost &func, vector<Edge*> &path)
{
  // find out the ID of the source and sink gcells
  const IdType srcGCellId = getGCellId(net.gCellOne);
  const IdType snkGCellId = getGCellId(net.gCellTwo);
  const Point snkGCellPT=gcellIdtoCoord(snkGCellId);

  // insert the source gcell into the priority queue
  priorityQueue.setGCellCost(srcGCellId, 0., 0., NULLID);

  // Instantiate the Cost function to calculate the Manhattan distance between
  // two gcells. This distance is used as the heuristic cost for A* search.
  ManhattanCost &lb = ManhattanCost::getFunc();
  EdgeCost &ed=EdgeCost::getFunc();
GCell neighbor1, neighbor2,neighbor3,neighbor4,neighbor5,neighbor6;
IdType currID,neighbor1_ID,neighbor2_ID,neighbor3_ID,neighbor4_ID,neighbor5_ID,neighbor6_ID;
Point currPT, neighbor1_PT,neighbor2_PT,neighbor3_PT,neighbor4_PT,neighbor5_PT,neighbor6_PT;
  // A* search kernel
  // Loop until all "frontiers" in the priority queue are exhausted, or when
  // the sink gcell is found.
  do {
    // YOUR A* search CODE GOES IN HERE
//Get ID of cell with smallest distance
currID=priorityQueue.getBestGCell();
GCell currGCell;

//get gCell reference of current GCell
currGCell=getGCell(currID);



//assign point to ID
currPT=gcellIdtoCoord(currID);
neighbor1_PT=currPT;
neighbor2_PT=currPT;
neighbor3_PT=currPT;
neighbor4_PT=currPT;
neighbor1_PT.x--;
neighbor1_ID=gcellCoordToId(neighbor1_PT.x,neighbor1_PT.y,neighbor1_PT.z);
neighbor2_PT.x++;
neighbor2_ID=gcellCoordToId(neighbor2_PT.x,neighbor2_PT.y,neighbor2_PT.z);
neighbor3_PT.y--;
neighbor3_ID=gcellCoordToId(neighbor3_PT.x,neighbor3_PT.y,neighbor3_PT.z);
neighbor4_PT.y++;
neighbor4_ID=gcellCoordToId(neighbor4_PT.x,neighbor4_PT.y,neighbor4_PT.z);

CostType neighbor1_hcost, neighbor2_hcost,neighbor3_hcost,neighbor4_hcost;
CostType neighbor1_pcost, neighbor2_pcost,neighbor3_pcost,neighbor4_pcost;


neighbor1_hcost=lb(neighbor1_PT,snkGCellPT);

priorityQueue.setGCellCost(neighbor1_ID,,currID);
    break; //got to get out of the loop somehow

    // YOUR A* search CODE ENDS HERE
  } while (!priorityQueue.isEmpty());

  // now backtrace and build up the path, if we found one
  // back-track from sink to source, and fill up 'path' vector with all the edges that are traversed
  if (priorityQueue.isGCellVsted(snkGCellId)) {
    // YOUR backtrace CODE GOES IN HERE


    // YOUR backtrace CODE ENDS HERE
  }

  // calculate the accumulated cost of the path
  const CostType finalCost =
      priorityQueue.isGCellVsted(snkGCellId) ?
          priorityQueue.getGCellData(snkGCellId).pathCost : numeric_limits<CostType>::max();

  // clean up
  priorityQueue.clear();

  return finalCost;
}


