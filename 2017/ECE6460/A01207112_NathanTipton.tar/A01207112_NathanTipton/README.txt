Nathan Tipton A01207112

• What is the purpose of each of the 3 stages in this routing algorithm? How are they different from
each other? 

Stage 1 (Initial route):
The algorithm attemps to route all the nets. The initial routing attempts to minimize area and meet timing constraints.
Priority here is to route all the nets.

Stage 2 (Rip-up and re-route):
If all the nets aren't able to be routed the algorithm may rip-up and re-route. 
The rip-up and re-route resolves bottlenecks and blocked connections.
Rip-up and re-route will repeat until all connections are routed or the operation times out.
Stage 3 (Greedy route):
In greedy route the algorithm will attempt to adjust the current routing inorder to find a local minima optimizing the routing.
It does this by taking any possible moves that would improve the routing.

How do they work together as a flow?
The initial routing attempts to route all connections. The better the initial routing can do, the less rip-up and re-routes will happen.
Rip-up and re-route fixes the inital route while greedy route attempts to optimize.
• How does SimpleGR build a framework to allow the 3 stages? (Think high-level, it should be brief)

SimpleGR reads the design file to find the grid size and number of nets.
SimpleGR sets up parameters such as maximum number of rip-up and reroute iterations and max runtime.
SimpleGR also sets the max number of iterations for the greedy route.