#include <stdlib.h>
#include <stdio.h>
#include <getopt.h> //Visual Studio doesn't like
#include <unistd.h> //Visual Studio doesn't like
#include <string.h> //Visual Studio doesn't like
#include <strings.h>
#include <math.h>
#include "cachelab.h" //Visual Studio doesn't like

typedef unsigned long long int memory_address;


//******SEE PAGE 617 For Details***********************
//lowercase (s) is the power you raise two by to get that number of sets (i.e. 2^s sets)
//lowercase (b) is the power you raise two by to get the size of your blocks (i.e. 2^b block size)
//uppercase (E) represents the number of lines per set.(See example below)
//uppercase (S) represents the number of sets. (i.e. S = 2^(lowercase s))
//uppercase (B) represents the size of each block (i.e. B = 2^(lowercase b))
//Example:
//input> ./csim -s 4 -E 1 -b 4 
//s = 4, S = 2^4 --> S = 16 (16 sets)
//E = 1, Each Set has 1 line (Example Below)
//Set 0: Set_Line_0:[valid],[Tag],[Cache Block]
//    
//Set 1: Set_Line_0:[valid],[Tag],[Cache Block]
//      
//b = 4, B = 2^4 --> b = 16 (16 Byte Cache Block)
typedef struct {
	int s, S, b, B, E;
	int hits, misses, evicts;
}cache_variables;


//Defines a Set_Line_N:[valid],[tag],[Cache Block]
//Last used must be used to reference the last access of the Set_Line_N
typedef struct {
	int last_used;
	int valid;
	memory_address tag;
	char *block;
}cache_line;

int verbosity;
//Defines the number of lines per cache set_line
//Example: E = 2
//Set 0: Set_Line_0:[valid],[Tag],[Cache Block]
//       Set_Line_1:[valid],[Tag],[Cache Block]
//
//Set 1: Set_Line_0:[valid],[Tag],[Cache Block]
//       Set_Line_1:[valid],[Tag],[Cache Block]
//......
//Set (S-1):
typedef struct {
	cache_line *lines;
}cache_set;


//Defines the number of sets (See above example)
typedef struct {
	cache_set *sets;
}cache;


//Prints Instructions
void instructions(char* argv[])
{
	printf("Usage: %s [-hv] -s <num> -E <num> -b <num> -t <file>\n", argv[0]);
	printf("Options:\n");
	printf("  -h         Print this help message.\n");
	printf("  -v         Optional verbose flag.\n");
	printf("  -s <num>   Number of set index bits.\n");
	printf("  -E <num>   Number of lines per set.\n");
	printf("  -b <num>   Number of block offset bits.\n");
	printf("  -t <file>  Trace file.\n");
	printf("\nExamples:\n");
	printf("  %s -s 4 -E 1 -b 4 -t traces/yi.trace\n", argv[0]);
	printf("  %s -v -s 8 -E 2 -b 4 -t traces/yi.trace\n", argv[0]);
	exit(0);
}


//Returns a cache
cache build_cache(long long number_sets, int number_lines, long long block_size) {

	cache newCache;    //Number of Sets
	cache_set set;  //Number of Lines per Set
	cache_line line;  //Set_Line_0:[valid], [Tag], [Cache Block] 
	int setIndex;   //Set 0:, Set 1:, Set 2:.....Set N
	int lineIndex;  //Set_Line_0:, Set_Line_1:, Set_Line_2:...Set_Line_N


					//newCache.sets = (cast_type*) malloc(space set aside in bytes)
					//newCache->sets = TYPE(Size = cache_set * num_sets)
	newCache.sets = (cache_set *)malloc(sizeof(cache_set) * number_sets);


	for (setIndex = 0; setIndex < number_sets; setIndex++)
	{
		//set.lines = (cast_type *) malloc(space set aside in bytes)
		//set->lines = TYPE(Size = cache_line * num_lines)
		//generate line for set at (setIndex)
		set.lines = (cache_line *)malloc(sizeof(cache_line) * number_lines);
		newCache.sets[setIndex] = set; //Add lines

									   // Populate each lines with default values
		for (lineIndex = 0; lineIndex < number_lines; lineIndex++)
		{
			line.last_used = 0;
			line.valid = 0;
			line.tag = 0;
			set.lines[lineIndex] = line;
		}

	}
	return newCache;
}


//Destructor
//Make a destructor to deallocate all of the allocated memory
void cache_destructor(cache simulator_cache, long long number_sets, int number_lines, long long block_size)
{
	int setIndex;
	//Set 0:, Set 1:, Set 2:.....Set
	//deallocate a specific set
	for (setIndex = 0; setIndex < number_sets; setIndex++)
	{
		cache_set set = simulator_cache.sets[setIndex];


		if (set.lines != NULL) {
			free(set.lines);
		}
	}
	//deallocate the sets
	if (simulator_cache.sets != NULL) {
		free(simulator_cache.sets);
	}
}

//Send 1 set at a time and determine if any of its lines are are empty
int find_empty_cache_line(cache_set set1, cache_variables values1) {
	int number_lines = values1.E;//Number of lines per set
	int i;						 //index
	cache_line lines;			 //Defines a Set_Line_N:[valid],[tag],[Cache Block]

	for (i = 0; i < number_lines; i++) {
		lines = set1.lines[i]; //Store set1
		if (lines.valid == 0) {
			return i;		   //Return index of valid line
		}
	}
	//no lines empty.
	return -1;
}

int find_evict_lines(cache_set set1, cache_variables values1, int *used_lines) {
	int number_lines = values1.E;				//Number of lines per set
	int maximum_used = set1.lines[0].last_used;   //Set minimum and maximum set lines to start at 0
	int minimum_used = set1.lines[0].last_used;
	int minimum_used_index = 0;					//Start at Index 0
	int i;

	cache_line lines;			 //Defines a Set_Line_N:[valid],[tag],[Cache Block]

	for (i = 1; i < number_lines; i++) {
		lines = set1.lines[i];	//Store set1

		if (minimum_used > lines.last_used) {
			minimum_used_index = i;
			minimum_used = lines.last_used;
		}

		if (maximum_used < lines.last_used) {
			maximum_used = lines.last_used;
		}
	}

	used_lines[0] = minimum_used;
	used_lines[1] = maximum_used;
	return minimum_used_index;
}

//fix names and write function
cache_variables simulator(cache Level_0, cache_variables values_0, memory_address address_0, char* instruction) {
	int lineIndex;
	int cache_full = 1;

	int number_lines = values_0.E;
	int previous_hits = values_0.hits;

	int tage_size = (64 - (values_0.s + values_0.b));
	memory_address input_tag = address_0 >> (values_0.s + values_0.b);
	unsigned long long temporary = address_0 << (tage_size);
	unsigned long long setIndex = temporary >> (tage_size + values_0.b);

	cache_set evaluate_set = Level_0.sets[setIndex];

	if(verbosity == 1 && strcmp(instruction, "N") != 0){
		printf(instruction);
		printf(" %llx", address_0);
		printf(",1");
	}


	for (lineIndex = 0; lineIndex < number_lines; lineIndex++) {

		cache_line lines = evaluate_set.lines[lineIndex];

		if (lines.valid) {

			if (lines.tag == input_tag) {
				if (verbosity == 1) { printf(" hit"); }

				lines.last_used++;
				values_0.hits++;
				evaluate_set.lines[lineIndex] = lines;
			}

		}
		else if (!(lines.valid) && (cache_full)) {

			cache_full = 0;
		}
	}

	if (previous_hits == values_0.hits) {
		values_0.misses++;
		if (verbosity == 1) { printf(" miss"); }
	}
	else {
		if(verbosity == 1 && strcmp(instruction, "M") != 0){
		printf("\n");
		}
		return values_0;
	}

	//Missed - Evict

	int *used_lines = (int*)malloc(sizeof(int) * 2);
	int minimum_used_index = find_evict_lines(evaluate_set, values_0, used_lines);

	if (cache_full) {
		if (verbosity == 1) { printf(" eviction"); }
		values_0.evicts++;

		//Found least recently used lines, overwrite it.
		evaluate_set.lines[minimum_used_index].tag = input_tag;
		evaluate_set.lines[minimum_used_index].last_used = used_lines[1] + 1;
	}

	else {
		int empty_index = find_empty_cache_line(evaluate_set, values_0);

		//found first empty line, write to it.
		evaluate_set.lines[empty_index].tag = input_tag;
		evaluate_set.lines[empty_index].valid = 1;
		evaluate_set.lines[empty_index].last_used = used_lines[1] + 1;
	}

	free(used_lines);
	if(verbosity == 1 && strcmp(instruction, "M") != 0){
		printf("\n");
	}
	return values_0;

}

long long bit_pow(int exp)
{
	long long result = 1;
	result = result << exp;
	return result;
}


int main(int argc, char **argv)
{

	cache simulator_cache;
	cache_variables variables;
	//void bzero(void *s, size_t n);
	//bzero places n zero-valued bytes in the area pointed to by variables;
	bzero(&variables, sizeof(variables));

	long long number_sets;
	long long block_size;

	//filestream
	FILE *read_input;

	memory_address address;
	int size;
	char command;
	char *file_input;
	char choice;

	//breaks apart input into each case.
	while ((choice = getopt(argc, argv, "s:E:b:t:vh")) != -1) {
		switch (choice)
		{
		case 's':
			//atoi: accepts a c-string to an integer and retuns that value
			//number = atoi("4569"), number = 4569 
			variables.s = atoi(optarg);
			break;
		case 'E':
			variables.E = atoi(optarg);
			break;
		case 'b':
			variables.b = atoi(optarg);
			break;
		case 't':
			file_input = optarg;
			break;
		case 'v':
			verbosity = 1;
			break;
		case 'h':
			instructions(argv);
			exit(0);
		default:
			instructions(argv);
			exit(1);
		}
	}

	//Ensure user input is valid
	if (variables.s == 0 || variables.E == 0 || variables.b == 0 || file_input == NULL) {
		printf("%s: Invalid Input. Ensure you have all the command line arguments\n", argv[0]);
		instructions(argv);
		exit(1);
	}

	//compute s and b
	//calculate the number of sets, 2 raised to a power of s
	number_sets = pow(2.0, variables.s);
	//calculate block size, using bit shifting.
	block_size = bit_pow(variables.b);

	//zero out hits, misses, and evicts
	variables.hits = 0;
	variables.misses = 0;
	variables.evicts = 0;

	//call build cache to build the cache
	simulator_cache = build_cache(number_sets, variables.E, block_size);

	//read in instructions I, L, S, M
	read_input = fopen(file_input, "r");

	//Make sure there are instructions to read
	if (read_input != NULL) {
		//fscanf: (FILE *stream, "single character, hexadecimal integer, decimal integer",
		// command, address, size);
		while (fscanf(read_input, " %c %llx, %d", &command, &address, &size) == 3) {
			switch (command) {
			case'I':
				break;
			case 'L':
				variables = simulator(simulator_cache, variables, address, "L");
				break;
			case 'S':
				variables = simulator(simulator_cache, variables, address, "S");
				break;
			case 'M':
				variables = simulator(simulator_cache, variables, address, "M");
				variables = simulator(simulator_cache, variables, address, "N");
				break;
			default:
				break;
			}
		}
	}

	printSummary(variables.hits, variables.misses, variables.evicts);
	cache_destructor(simulator_cache, number_sets, variables.E, block_size);
	fclose(read_input);


	return 0;
}
