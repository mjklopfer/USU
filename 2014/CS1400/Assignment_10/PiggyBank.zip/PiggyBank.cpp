#include <cstdlib>
#include <iostream>
#include "PiggyBank.h"

using namespace std;
PiggyBank::PiggyBank(){ broken = false, savings = 0; }
PiggyBank::PiggyBank(double deposit, bool){ broken = false, savings = deposit; }

double PiggyBank::countSavings(){
	return savings;
}
double PiggyBank::depositMoney(double deposit){
	if (deposit < 0)deposit = 0;
	savings=deposit + savings;
	return savings;
}
double PiggyBank::smash(){
	broken = true;
	savings = 0;
	return savings;
}
