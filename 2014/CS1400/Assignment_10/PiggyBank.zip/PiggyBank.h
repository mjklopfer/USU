#ifndef PiggyBank_H
#define PiggyBank_H


#include <cstdlib>
#include <iostream>
using namespace std;

class PiggyBank{

public:
	//constructor
	PiggyBank();
	PiggyBank(double savings, bool broken);
	//member functions
	double countSavings();
	double depositMoney(double deposit);
	double smash();
	//destructor
	~PiggyBank(){ if (broken == true)cout << "Nooooo!!!\n"; }


private:
	//private data
	bool broken;
	double savings;
};

#endif